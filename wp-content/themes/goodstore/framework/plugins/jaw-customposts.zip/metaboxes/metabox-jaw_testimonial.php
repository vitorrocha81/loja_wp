<?php
global $custom_meta_testamontial;


$custom_meta_testamontial[] = array("label" => "Position",
    "desc" => "",
    "id" => "_testimontial_possition",
    "std" => "",
    "type" => "text");


$custom_meta_testamontial[] = array("label" => "Photo",
    "desc" => "",
    "id" => "_testimontial_photo",
    "std" => "",
    "type" => "simplemediapicker");



?>
