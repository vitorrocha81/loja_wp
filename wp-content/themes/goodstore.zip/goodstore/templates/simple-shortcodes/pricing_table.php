<?php global $jaw_data; ?>
<div class="jaw-pricing-table">
<?php
echo do_shortcode(jaw_template_get_var('content'));
?>
</div>