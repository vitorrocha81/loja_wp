<?php
global $jaw_data;
?>
<link media="all" type="text/css" href="http://fonts.googleapis.com/css?family=<?php echo jaw_template_get_var('font_family');?>" rel="stylesheet">

<span style="font-family:<?php echo jaw_template_get_var('font_family'); ?>;font-size:<?php echo jaw_template_get_var('font_size'); ?>px;color:<?php echo jaw_template_get_var('color'); ?>;">
    <?php echo jaw_template_get_var('content'); ?>
</span>

