<div class="totop-button" id="totop" >
    <i class="icon-arrow-slide-up"></i>
</div>